<?php
/**
 * Theme Customizer classes
 *
 * @package Styleguide
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return NULL;
}


/**
 * Insert your custom classes here
 */
 
