# colorizer #
**Contributors:** charmeem

**Tags:** customizer,plugin, themes, colors

**Donate link:** 

**Requires at least:** 4.2

**Tested up to:** 4.4

**Stable tag:** 1.0

**License:** GPLv2 or later

**License URI:** http://www.gnu.org/licenses/gpl-2.0.html

A simple plugin to create customize Color scheme through WordPress Customizer.


## Description ##

Utilizes WorPress Customizer Functionality

Give websites unique look by generating cool color schemes in the live preview window without need to load the webpage.

Supports multiple themes. So Far tested with:
* Twenty Twelve
* Graphy
* Customizr

Modular Design approach helps developer to add more themes with minumum effort.


## Installation ##

From your dashboard go to Plugins => Add New.
Search for "colorizer" and install it.
Once you install it, activate it.
For configuration instructions please visit the [site to come]

## Frequently Asked questions ##
So far none.

## Screenshots ##
The samples of the plugin is included in the same path.
## Upgrade Notice ##
New update plan will follow soon
## Changelog ##

##### 1.0. #####
January 31, 2016

* Initial version

